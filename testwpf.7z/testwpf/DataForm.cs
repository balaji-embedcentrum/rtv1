﻿using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rtView
{
    public partial class DataForm : Form
    {
        
        private DateTime lastUpdate = DateTime.Now;

        public DataForm()
        {   
            InitializeComponent();
        }

        public PlotModel plotmodel1;
        
        private readonly List<OxyColor> colors = new List<OxyColor>
                                            {
                                                OxyColors.Green,
                                                OxyColors.IndianRed,
                                                OxyColors.Coral,
                                                OxyColors.Chartreuse,
                                                OxyColors.Azure
                                            };

        private readonly List<MarkerType> markerTypes = new List<MarkerType>
                                                   {
                                                       MarkerType.Plus,
                                                       MarkerType.Star,
                                                       MarkerType.Diamond,
                                                       MarkerType.Triangle,
                                                       MarkerType.Cross
                                                   };


        private void SetUpModel()
        {   
            plotmodel1.LegendTitle = "Legend";
            plotmodel1.LegendOrientation = LegendOrientation.Horizontal;
            plotmodel1.LegendPlacement = LegendPlacement.Outside;
            plotmodel1.LegendPosition = LegendPosition.TopRight;
            plotmodel1.LegendBackground = OxyColor.FromAColor(200, OxyColors.White);
            plotmodel1.LegendBorder = OxyColors.Black;

            var dateAxis = new DateTimeAxis(AxisPosition.Bottom, "Date", "HH:mm") { MajorGridlineStyle = LineStyle.Solid, MinorGridlineStyle = LineStyle.Dot, IntervalLength = 80 };
            plotmodel1.Axes.Add(dateAxis);
            var valueAxis = new LinearAxis(AxisPosition.Left, 0) { MajorGridlineStyle = LineStyle.Solid, MinorGridlineStyle = LineStyle.Dot, Title = "Value" };
            plotmodel1.Axes.Add(valueAxis);

        }

        private void LoadData()
        {
            List<Measurement> measurements = Data.GetData();

            var dataPerDetector = measurements.GroupBy(m => m.DetectorId).OrderBy(m => m.Key).ToList();

            foreach (var data in dataPerDetector)
            {
                var lineSerie = new LineSeries
                {
                    StrokeThickness = 2,
                    MarkerSize = 3,
                    MarkerStroke = colors[data.Key],
                    MarkerType = markerTypes[data.Key],
                    CanTrackerInterpolatePoints = false,
                    Title = string.Format("Variable {0}", data.Key),
                    Smooth = false,
                };

                data.ToList().ForEach(d => lineSerie.Points.Add(new DataPoint(DateTimeAxis.ToDouble(d.DateTime), d.Value)));
                plotmodel1.Series.Add(lineSerie);
            }
            lastUpdate = DateTime.Now;
            
        }

        public void UpdateModel()
        {
            List<Measurement> measurements = Data.GetUpdateData(lastUpdate);
            var dataPerDetector = measurements.GroupBy(m => m.DetectorId).OrderBy(m => m.Key).ToList();

            foreach (var data in dataPerDetector)
            {
                var lineSerie = plotmodel1.Series[data.Key] as LineSeries;
                if (lineSerie != null)
                {
                    data.ToList()
                        .ForEach(d => lineSerie.Points.Add(new DataPoint(DateTimeAxis.ToDouble(d.DateTime), d.Value)));
                }
            }
            lastUpdate = DateTime.Now;
        }
        public void GetPADFormActive()
        {
            const uint MCP2210_VID = 0x04D8;   // VID for Microchip Technology Inc.
            const uint MCP2210_PID = 0x00DE;   // PID for MCP2210

            
            //MCP2210.DevIO UsbSpi = new DevIO(MCP2210_VID, MCP2210_PID);
            
            var plotmodel1 = new PlotModel();
            /*
             //plotModel1.Title = "Touch on a LineSeries";
             var linearAxis1 = new LinearAxis();
             linearAxis1.Position = AxisPosition.Bottom;
             plotModel1.Axes.Add(linearAxis1);
             var linearAxis2 = new LinearAxis();
             plotModel1.Axes.Add(linearAxis2);
             var lineSeries1 = new LineSeries();
             var lineSeries2 = new LineSeries();
             lineSeries1.Points.Add(new DataPoint(0, 0));
             lineSeries1.Points.Add(new DataPoint(3, 7));
             lineSeries1.Points.Add(new DataPoint(10, 10));
             lineSeries2.Points.Add(new DataPoint(0, 3));
             lineSeries2.Points.Add(new DataPoint(2, 5));
             lineSeries2.Points.Add(new DataPoint(5, 8));
             lineSeries2.Points.Add(new DataPoint(7, 18));
             plotModel1.Series.Add(lineSeries1);
             plotModel1.Series.Add(lineSeries2);
             plot1.Model = plotModel1;
             plot1.HideTracker();
             //m_Model.ImportDataModel();
             //InitVirtualListViewNodes();*/

#if False
            plotmodel1.LegendTitle = "Legend";
            plotmodel1.LegendOrientation = LegendOrientation.Horizontal;
            plotmodel1.LegendPlacement = LegendPlacement.Outside;
            plotmodel1.LegendPosition = LegendPosition.TopRight;
            plotmodel1.LegendBackground = OxyColor.FromAColor(200, OxyColors.White);
            plotmodel1.LegendBorder = OxyColors.Black;
#endif

            var dateAxis = new DateTimeAxis(AxisPosition.Bottom, "Date", "HH:mm") { MajorGridlineStyle = LineStyle.Solid, MinorGridlineStyle = LineStyle.Dot, IntervalLength = 80 };
            plotmodel1.Axes.Add(dateAxis);
            var valueAxis = new LinearAxis(AxisPosition.Left, 0) { MajorGridlineStyle = LineStyle.Solid, MinorGridlineStyle = LineStyle.Dot, Title = "Value" };
            plotmodel1.Axes.Add(valueAxis);

            List<Measurement> measurements = Data.GetData();

            var dataPerDetector = measurements.GroupBy(m => m.DetectorId).OrderBy(m => m.Key).ToList();

            foreach (var data in dataPerDetector)
            {
                var lineSerie = new LineSeries
                {
                    StrokeThickness = 2,
                    MarkerSize = 3,
                    MarkerStroke = colors[data.Key],
                    MarkerType = markerTypes[data.Key],
                    CanTrackerInterpolatePoints = false,
                    Title = string.Format("Variable {0}", data.Key),
                    Smooth = false,
                };

                data.ToList().ForEach(d => lineSerie.Points.Add(new DataPoint(DateTimeAxis.ToDouble(d.DateTime), d.Value)));
                plotmodel1.Series.Add(lineSerie);
            }
            lastUpdate = DateTime.Now;
            plot1.Model = plotmodel1;

            lstDataView.Text = dn.Name;
            ListViewItem.ListViewSubItem lvsi1 = new ListViewItem.ListViewSubItem();
            lvsi1.Text = dn.CountChildren.ToString(CultureInfo.InvariantCulture);
            ListViewItem.ListViewSubItem lvsi2 = new ListViewItem.ListViewSubItem();
            lvsi2.Text = dn.Level.ToString(CultureInfo.InvariantCulture);
            ListViewItem.ListViewSubItem lvsi3 = new ListViewItem.ListViewSubItem();
            lvsi3.Text = dn.Comment;

            lvi.IndentCount = dn.Level;

            lvi.SubItems.Add(lvsi1);
            lvi.SubItems.Add(lvsi2);
            lvi.SubItems.Add(lvsi3);

            if (dn.Expanded)
                lvi.StateImageIndex = 1;
            else if (dn.CountChildren > 0)
                lvi.StateImageIndex = 0;

            return lvi;
            
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }



    }
}
