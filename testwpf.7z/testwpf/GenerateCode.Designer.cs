﻿namespace rtView
{
    partial class GenerateCode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCFile = new System.Windows.Forms.TextBox();
            this.txtHFile = new System.Windows.Forms.TextBox();
            this.btnCFile = new System.Windows.Forms.Button();
            this.btnHFile = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnGenCode = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Source Code (.c) File:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Source Header (.h) File:";
            // 
            // txtCFile
            // 
            this.txtCFile.Location = new System.Drawing.Point(149, 36);
            this.txtCFile.Name = "txtCFile";
            this.txtCFile.Size = new System.Drawing.Size(425, 20);
            this.txtCFile.TabIndex = 2;
            // 
            // txtHFile
            // 
            this.txtHFile.Location = new System.Drawing.Point(149, 74);
            this.txtHFile.Name = "txtHFile";
            this.txtHFile.Size = new System.Drawing.Size(425, 20);
            this.txtHFile.TabIndex = 3;
            // 
            // btnCFile
            // 
            this.btnCFile.Location = new System.Drawing.Point(580, 34);
            this.btnCFile.Name = "btnCFile";
            this.btnCFile.Size = new System.Drawing.Size(24, 23);
            this.btnCFile.TabIndex = 4;
            this.btnCFile.Text = "...";
            this.btnCFile.UseVisualStyleBackColor = true;
            // 
            // btnHFile
            // 
            this.btnHFile.Location = new System.Drawing.Point(580, 72);
            this.btnHFile.Name = "btnHFile";
            this.btnHFile.Size = new System.Drawing.Size(24, 23);
            this.btnHFile.TabIndex = 5;
            this.btnHFile.Text = "...";
            this.btnHFile.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(338, 139);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(104, 44);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnGenCode
            // 
            this.btnGenCode.Location = new System.Drawing.Point(470, 139);
            this.btnGenCode.Name = "btnGenCode";
            this.btnGenCode.Size = new System.Drawing.Size(104, 44);
            this.btnGenCode.TabIndex = 7;
            this.btnGenCode.Text = "Generate Code";
            this.btnGenCode.UseVisualStyleBackColor = true;
            // 
            // GenerateCode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 206);
            this.Controls.Add(this.btnGenCode);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnHFile);
            this.Controls.Add(this.btnCFile);
            this.Controls.Add(this.txtHFile);
            this.Controls.Add(this.txtCFile);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "GenerateCode";
            this.Text = "GenerateCode";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCFile;
        private System.Windows.Forms.TextBox txtHFile;
        private System.Windows.Forms.Button btnCFile;
        private System.Windows.Forms.Button btnHFile;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnGenCode;
    }
}