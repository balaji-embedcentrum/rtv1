﻿using OxyPlot;
using OxyPlot.Annotations;
using OxyPlot.Axes;
using OxyPlot.Series;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MCP2210;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Reflection;
using rtView;
using System.Xml.Linq;
using System.Xml;


namespace rtView
{
    public partial class MainForm : Form
    {
        public MainForm()
        {           
            InitializeComponent();
        }
        //public SaveFileDialog savePADFile = new SaveFileDialog();
        private void quitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void newPADFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtView.PADForm newMDIChild = new rtView.PADForm();
            // Set the Parent Form of the Child window.
            
            newMDIChild.MdiParent = this;
            // Display the new form.
            this.saveToolStripMenuItem.Enabled = true;
            this.generateCodeToolStripMenuItem.Enabled = true;
                        
            newMDIChild.Show();
        }

        private void openDataFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtView.DataForm newMDIChild = new rtView.DataForm();
            newMDIChild.MdiParent = this;
            newMDIChild.GetPADFormActive();
            this.saveToolStripMenuItem.Enabled = true;
            this.generateCodeToolStripMenuItem.Enabled = true;
            newMDIChild.Show();            
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Displays a SaveFileDialog so the user can save the Image
            // assigned to Button2.
            rtView.PADForm newMDIChild = new rtView.PADForm();                       
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm fm = (MainForm)Application.OpenForms[0].FindForm();
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "PADFile | *.pad";
            DialogResult dr = ofd.ShowDialog(fm);
            if (DialogResult.OK == dr)
            {
                String PADFilePath = ofd.FileName;
                XDocument document = XDocument.Load(PADFilePath);
                rtView.PADForm newMDIChild = new rtView.PADForm();
                newMDIChild.MdiParent = this;  
                newMDIChild.Show();
                newMDIChild.PopulatePADData(document);
            }
        }

        private void versionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtView.About About = new rtView.About();
            About.Show();
        }

        private void captureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtView.CaptureData Capture = new rtView.CaptureData();
            Capture.Show();

        }
        

    }
}
