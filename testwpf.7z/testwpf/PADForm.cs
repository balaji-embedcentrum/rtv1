﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace rtView
{
    public partial class PADForm : Form
    {
        public PADForm()
        {
            InitializeComponent();
        }
        public String[,] DataList = new String[100,6];
        public XDocument PADocument = new XDocument();
        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            int iAvailableItems = lstData.Items.Count;
            if (iAvailableItems < 100)
            {
                DataList[iAvailableItems, 0] = txtVariable.Text;
                DataList[iAvailableItems, 1] = cmbVarSize.SelectedItem.ToString();
                DataList[iAvailableItems, 2] = txtHeader.Text;
                DataList[iAvailableItems, 3] = txtResolution.Text;
                DataList[iAvailableItems, 4] = txtUnit.Text;
                DataList[iAvailableItems, 5] = rtbDesc.Text;
                lstData.Items.Add(DataList[iAvailableItems, 0]);
            }
        }

                       
        public int GetListBoxItems()
        {
            int iListBoxItems = lstData.Items.Count;
            return iListBoxItems;
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int iSelectedVar = lstData.SelectedIndex;
            DataList[iSelectedVar, 0] = txtVariable.Text;
            DataList[iSelectedVar, 1] = cmbVarSize.SelectedItem.ToString();
            DataList[iSelectedVar, 2] = txtHeader.Text;
            DataList[iSelectedVar, 3] = txtResolution.Text;
            DataList[iSelectedVar, 4] = txtUnit.Text;
            DataList[iSelectedVar, 5] = rtbDesc.Text;            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog savePADFile = new SaveFileDialog();
            savePADFile.Filter = "PAD File|*.pad";
            savePADFile.Title = "Save PAD File";
            savePADFile.ShowDialog();

            // If the file name is not an empty string open it for saving.
            if (savePADFile.FileName != "")
            {
                this.SavePADFileData(savePADFile);
            }      
        }

        public void SavePADFileData(SaveFileDialog savePADFile)
        {
            /*
                * You can use an XDocument to create an XML file, and that includes XML
                * files you can read and write using DataContractSerializer.
                *
                * An XMLDocument object represents an XML document. It's part of the
                * System.Xml.Linq namespace.
                *
                * Use XElement objects to create elements under the XML tree.
                */

            XmlDocument doc = new XmlDocument();

            //Xml Declaration
            XmlDeclaration declaration = doc.CreateXmlDeclaration("1.0", "utf-8", "yes");
            //Attach declaration to the document
            doc.AppendChild(declaration);

            //Create a comment
            XmlComment comment = doc.CreateComment("Perfint SPI Transfer Data Description");
            //Attach comment to the document
            doc.AppendChild(comment);

            //Create root element
            XmlElement root = doc.CreateElement("perfintspi");
            //Attach the root node to the document
            doc.AppendChild(root);
            //int iAvailableItems = lstData.Items.Count;
            int iItemCount = lstData.Items.Count;
            for (int i = 0; i < iItemCount; i++)
            {
                //Create a Person child element
                XmlElement variable = doc.CreateElement("Variable");
                //Add an attribute name with value John Smith
                XmlElement variablename = doc.CreateElement("name");
                variablename.InnerText = DataList[i, 0];
                XmlElement variablesize= doc.CreateElement("size");
                variablesize.InnerText = DataList[i, 1];
                XmlElement variableheader = doc.CreateElement("header");
                variableheader.InnerText = DataList[i, 2];
                XmlElement variableres = doc.CreateElement("resolution");
                variableres.InnerText = DataList[i, 3];
                XmlElement variableunit = doc.CreateElement("unit");
                variableunit.InnerText = DataList[i, 4];
                XmlElement variabledesc = doc.CreateElement("description");
                variabledesc.InnerText = DataList[i, 5];

                //Attach Age and Gender element to the Person element
                variable.AppendChild(variablename);
                variable.AppendChild(variablesize);
                variable.AppendChild(variableheader);
                variable.AppendChild(variableres);
                variable.AppendChild(variableunit);
                variable.AppendChild(variabledesc);
                doc.DocumentElement.AppendChild(variable);
            }
            doc.Save(@savePADFile.FileName);
        }
        public void PopulatePADData(XDocument document)
        {
            var SPIData = from r in document.Descendants("Variable")
                          select new
                          {
                              Name = r.Element("name").Value,
                              Size = r.Element("size").Value,
                              Header = r.Element("header").Value,
                              Resolution = r.Element("resolution").Value,
                              Unit = r.Element("unit").Value,
                              Description = r.Element("description").Value
                          };
            int iListCount;
            iListCount = 0;
            foreach (var d in SPIData)
            {
                lstData.Items.Add(d.Name);
                DataList[iListCount, 0] = d.Name;
                DataList[iListCount, 1] = d.Size;
                DataList[iListCount, 2] = d.Header;
                DataList[iListCount, 3] = d.Resolution;
                DataList[iListCount, 4] = d.Unit;
                DataList[iListCount, 5] = d.Description;
                iListCount++;
            }
            lstData.SetSelected(0, true);
            txtVariable.Text = DataList[0,0];
            cmbVarSize.Text = DataList[0, 1];
            txtHeader.Text = DataList[0, 2];
            txtResolution.Text = DataList[0, 3];
            txtUnit.Text = DataList[0, 4];
            rtbDesc.Text = DataList[0, 5];

            PADocument = document;
        }

        private void lstData_SelectedIndexChanged(object sender, EventArgs e)
        {
            int iSelectedVar = lstData.SelectedIndex;
            txtVariable.Text = DataList[iSelectedVar, 0];
            cmbVarSize.Text = DataList[iSelectedVar, 1];
            txtHeader.Text = DataList[iSelectedVar, 2];
            txtResolution.Text=DataList[iSelectedVar, 3];
            txtUnit.Text = DataList[iSelectedVar, 4];
            rtbDesc.Text = DataList[iSelectedVar, 5];              
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            rtView.GenerateCode GenCode = new rtView.GenerateCode();
            GenCode.Show();
        }           
    }
}
